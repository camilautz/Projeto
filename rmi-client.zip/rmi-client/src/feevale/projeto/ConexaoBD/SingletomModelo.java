package feevale.projeto.ConexaoBD;

/**
 *
 * @author Camila Utz
 */
public class SingletomModelo {
    
    /* Cria-se um atributo estático que permitirá a manipulação e controle
	 * da instância criada */
	private static SingletomModelo mySelf;
	
	/* Primeiro passo para a criação de um Sigletom é a declaração de um construtor 
	 * privado, como abaixo.  Este providencia impede que esta classe seja instanciada
	 * for dela mesmo.
	 */
	private SingletomModelo() {
		
	}
	
	/* Finalmente adiciona-se à classe um método estático, que retornará a instância
	 * criada da classe Singletom */
	public static SingletomModelo getInstance() {
		
		if( mySelf == null ) {
			mySelf = new SingletomModelo();
		}
		
		return mySelf;
	}
    
}
