/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.feevale.client;

import br.com.feevale.core.Service;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author pbarros
 */
public class Main {
    static Scanner s = new Scanner(System.in);
    static Registry registry;
    static Service _srv; 
    static String dataInicial;
    static String dataFinal;
    static String noticia;
    static int qtdeCaracteres = 180;
    
    public static void main(String[] args) throws RemoteException, NotBoundException {        
        try {
            registry = LocateRegistry.getRegistry("192.168.2.103", Registry.REGISTRY_PORT);
            _srv = (Service) registry.lookup("192.168.2.103/service");
            
            int menuInicial = -1;
            while (menuInicial != 6){
                System.out.println("\n######## Menu Atividade ########\n");
                System.out.println("Escolha uma opcao:");
                System.out.println("1 - Logado como escritor");
                System.out.println("2 - Logado como leitor de noticias (Cadastrado)");
                System.out.println("3 - Nao logado, apenas leitor de noticias (Nao cadastrado)");
                System.out.println("4 - Realizar Backup");
                System.out.println("5 - Restaurar Backup");
                System.out.println("6 - Sair");
                menuInicial = s.nextInt();
                try{
                    switch (menuInicial){
                        case 1:
                            //logado como escritor 
                            escritorNoticiasConectado();
                            break;                        
                        case 2:
                            //logado como leitor
                            leitorNoticiasConectado();
                            break;                            
                        case 3:
                            //nao logado e nao cadastrado
                            leitorNoticiasDesconectado();                            
                            break;                            
                        case 4:
                            //realizar backup
                            _srv.realizarBackup();
                            break;                        
                        case 5:
                            //realizar backup
                            System.out.println(_srv.restaurarBackup());
                            break;                            
                        case 6:
                            //sair
                            System.out.println("FIM!!!");
                            break;                            
                        default:
                            System.out.println("Opcao Invalida!!!");                            
                    }                    
                }catch(InputMismatchException e){
                    s.reset();
                    System.err.println("Escolha uma opcao de 1 a 6!");
                }
            }       
        } catch(RemoteException e) {
            System.err.println("Ocorreu um erro relativo ao RMI: " + e.getMessage());
            e.printStackTrace();
            System.exit(0);
        } catch(Exception e) {
            System.err.println("Ocorreu um erro desconhecido: " + e.getMessage());
            e.printStackTrace();
            System.exit(0);
        }   
        /*   
        Scanner input = new Scanner(System.in);
        String read ="";
        while (!read.equalsIgnoreCase("exit")) {
            
            System.out.println("Digite uma string");
            String _resp = _srv.invertString(input.nextLine());
            System.out.println(_resp+"-"+_srv.getDataHora());
            _srv.getDataHora();
            
            System.out.println("\nPara sair digite exit ou outra tecla para continuar!");
            read=input.nextLine();
        }*/
    }
    
    public static int escritorNoticiasConectado() throws RemoteException{
        int flag = 0;
        int menuEscritor = -1; 
        while (menuEscritor != 5){
            System.out.println("\n-------- Menu Escritor --------");
            System.out.println("1 - Adicionar Tópico de noticias");
            System.out.println("2 - Consultar tópicos existentes");
            System.out.println("3 - Inserir noticia em topico");
            System.out.println("4 - Consultar todas as noticias");
            System.out.println("5 - Desconectar");

            menuEscritor = s.nextInt();
            try{
                switch (menuEscritor){
                    case 1:
                        //adicionar topico                
                        System.out.println("Digite o nome do topico a ser criado: ");
                        s.reset();
                        String nome = s.next();
                        _srv.adicionarTopico(nome);
                        break;                    
                    case 2:
                        //consultar topicos existentes
                        System.out.println("Consulta dos topicos existentes: ");
                        _srv.listarTopicos();
                        break;
                    case 3:
                        //inserir noticia para um topico                    
                        _srv.inserirNoticiaEmTopico(menuTopico(), escreverNoticia());
                        /*
                        _srv.postMessage("autor", "Java RMI e muito legal");
                        _srv.postMessage("autor", "Nunca poste no forum sem buscar");
                        */
                        break;
                    case 4:
                        //consultar todas as noticias
                        System.out.println("Lista de todas as noticias: ");
                        System.out.println("Consulta de todas as noticias: \n" +_srv.consultarTodasAsNoticias());                    
                        break;
                    case 5:
                        //desconectar
                        System.out.println("Escritor desconectado...");    
                        break;
                    default:
                        System.err.println("Opcao invalida");    
                }                                  
            }catch (InputMismatchException e){                
                s.reset();               
                System.err.println("Escolha uma opcao de 1 a 5!");                                                   
            } 
        }
        return flag;
    }
    
    public static int leitorNoticiasConectado() throws RemoteException{
        int flag = 0;
        
            int menuLeitorCadastrado = -1; 
            while (menuLeitorCadastrado != 4){
            System.out.println("\n-------- Menu Leitores cadastrados --------");
            System.out.println("1 - Inscrever em 1 topico");
            System.out.println("2 - Consultar noticias de 1 topico em intervalo de datas");
            System.out.println("3 - Consultar ultima noticia de 1 topico");
            System.out.println("4 - Desconectar");

            menuLeitorCadastrado = s.nextInt();
            try{
                switch (menuLeitorCadastrado){
                    case 1:
                        //inscrever em 1 topico
                        _srv.inscreverEmTopico(menuTopico());                                       
                        break;                    
                    case 2:
                        //consultar noticias de 1 topico em intervalo de datas
                        int topico = menuTopico();
                        pesquisaData();                    
                        System.out.println("Consulta de noticia por data: \n" + _srv.consultarNoticiaDeTopicoPorData(topico, dataInicial, dataFinal));
                        /*
                        String[] posts = _srv.readPosts();

                                int x = 1;
                                for(String s: posts)
                                    System.out.println(x++ + ": "+ s);

                                int offset = 1;
                                posts = _srv.readPosts(offset);
                                for(String s: posts)
                                    System.out.println((x++ + offset) + ": "+ s); 
    */
                        break;
                    case 3:
                        //consultar a ultima noticia de 1 topico
                        System.out.println("Consulta da ultima noticia: \n" +_srv.consultarUltimaNoticiaDeTopico(menuTopico()));
                        break;
                    case 4:
                            //desconectar
                            System.out.println("Leitor cadastrado desconectado...");    
                            break;
                    default:
                        System.err.println("Opcao invalida");    
                }                                  
            }catch (InputMismatchException e){                
                s.reset();               
                System.err.println("Escolha uma opcao de 1 a 4!");                                                   
            }
        }
        return flag;
    }
    
    public static int leitorNoticiasDesconectado() throws RemoteException{
        int flag = 0;
        
        int menuLeitorNaoCadastrado = -1;
        while (menuLeitorNaoCadastrado != 3){
            System.out.println("\n-------- Menu Leitores NAO cadastrados --------");        
            System.out.println("1 - Consultar noticias de 1 topico em intervalo de datas");
            System.out.println("2 - Consultar ultima noticia de 1 topico");
            System.out.println("3 - Voltar...");

            menuLeitorNaoCadastrado = s.nextInt();
            try{
                switch (menuLeitorNaoCadastrado){                             
                    case 1:
                        //consultar noticias de 1 topico em intervalo de datas
                         int topico = menuTopico();
                        pesquisaData();                    
                        System.out.println("Consulta de noticia por data: \n" + _srv.consultarNoticiaDeTopicoPorData(topico, dataInicial, dataFinal));
                        /*
                        String[] posts = _srv.readPosts();

                                int x = 1;
                                for(String s: posts)
                                    System.err.println(x++ + ": "+ s);

                                int offset = 1;
                                posts = _srv.readPosts(offset);
                                for(String s: posts)
                                    System.err.println((x++ + offset) + ": "+ s); */                   
                        break;
                    case 2:
                        //consultar a ultima noticia de 1 topico
                        _srv.consultarUltimaNoticiaDeTopico(menuTopico());
                        break;
                    case 3:
                            //desconectar
                            System.out.println("Leitor não cadastrado...");    
                            break;
                    default:
                        System.err.println("Opcao invalida!");    
                }                                  
            }catch (InputMismatchException e){                
                s.reset();               
                System.err.println("Escolha uma opcao de 1 a 3!");                                                   
            }
        }
        return flag;
    }
    
    public static int menuTopico() throws RemoteException{
        int indice = 0;
        System.out.println("Topico disponiveis\n" + _srv.listarTopicos());
        System.out.println("Escolha o numero do topico que deseja: ");
        s.reset();
        indice = s.nextInt();        
        return indice;
    }
    
    public static void pesquisaData() throws RemoteException{        
        System.out.println("Digite o intervalo que deseja: ");
        System.out.println("Data inicial: ");
        dataInicial = s.next();
        System.out.println("Data final: ");
        dataFinal = s.next();
    }
    
    public static String escreverNoticia(){
        System.out.println("Escreva a noticia (limite maximo de " + qtdeCaracteres + " caracteres): ");
        s.reset();
        noticia = s.next();
        limitaString(noticia);
        return noticia;
    }
    
    public static String limitaString(String noticia){        
        if (noticia.length() <= qtdeCaracteres){
            return noticia;
        }else{
            return noticia.substring(0, qtdeCaracteres);
        }
    }
    
    public String getDataInicial(){
        return dataInicial;
    }
    
    public String getDataFinal(){
        return dataFinal;
    }
    
    public String getNoticia(){
        return noticia;
    }
    
    public int getQtdeCaracteres(){
        return qtdeCaracteres;
    }
     
    public void setDataInicial(String dataInicial){
        this.dataInicial = dataInicial;
    }
    
    public void setDataFinal(String dataFinal){
        this.dataFinal = dataFinal;
    }
    
    public void setNoticia(String noticia){
        this.noticia = noticia;
    }
    
    public void setQtdeCaracteres(int qtdeCaracteres){
        this.qtdeCaracteres= qtdeCaracteres;
    }       
}
