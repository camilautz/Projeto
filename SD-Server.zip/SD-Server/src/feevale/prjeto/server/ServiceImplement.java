package feevale.prjeto.server;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Camila Utz
 */
public class ServiceImplement{
   
    
    //Salvar a data e a hora da conexão
    public String getDataHora() throws RemoteException{
        SimpleDateFormat _dateTimeFormat = new SimpleDateFormat ("dd/MM/yyyyb HH:mm");
        return _dateTimeFormat.format(Calendar.getInstance().getTime());
    }
    
    
    public boolean mVerificaAcesso() throws RemoteException {
        
       
      
        return false;
    
    }
}
   
