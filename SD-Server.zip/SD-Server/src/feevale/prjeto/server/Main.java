package feevale.prjeto.server;

import connection.DAO;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.security.Provider.Service;
import java.sql.SQLException;

/**
 *
 * @author Camila Utz
 */
public class Main{
    
    public static void main(String [] args) throws RemoteException, SQLException{
    
        Registry registry = LocateRegistry.createRegistry(9999);
        ServiceImplement _srvImp = new ServiceImplement();
        Service _serv = (Service) UnicastRemoteObject.exportObject((Remote) _srvImp, 0);
        registry.rebind("127.0.0.1/service", (Remote) _serv);
        System.out.println("Servidor no ar!");
        String dataHora = new String();
        dataHora = DAO.pesquisar("select now() as dataAgora");
        System.out.println(dataHora);
    }
    
    
}
