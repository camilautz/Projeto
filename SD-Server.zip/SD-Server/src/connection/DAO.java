/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Igor
 */
public class DAO {
       static Connection conexao = null;
	public static Connection getConexao() {
		
		String usuario = "root";
		String senha = "root";
		String nomeBancoDados = "world";
             
		try {
                   Class.forName("com.mysql.jdbc.Driver"); 
                    if(conexao == null){
                        conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + nomeBancoDados,
					 usuario, senha);
                     }       
			 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conexao;
	}
        
        //exemplo de query nao retornando valores
        public static void buscaData(String sql) {
            getConexao();
              try {
                      PreparedStatement pstm = conexao.prepareStatement(sql); 

                  pstm.execute();
                  pstm.close();
                  //conexao.close();
              } catch (SQLException e) {
                      e.printStackTrace();
              }
      }
        //exemplo de query retornando valores
        public static String pesquisar(String sql) throws SQLException{
            getConexao();
            PreparedStatement pstm = conexao.prepareStatement(sql); 
            ResultSet rs = pstm.executeQuery(sql);
            pstm.execute();
            pstm.close();
            String val="";
            //select now() as dataAgora
              if(rs != null && rs.next()){
                    val = rs.getString("dataAgora");
                }
                System.out.println(val);
            return val;
                  
        }          
}
