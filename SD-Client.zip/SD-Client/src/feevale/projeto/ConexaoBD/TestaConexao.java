package feevale.projeto.ConexaoBD;

import feevale.projeto.ConexaoBD.Conexao;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Camila Utz
 */
public class TestaConexao {
    
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {

		ParametrosBD.getInstance().inicParametros();
		
		
		System.out.println( "Vou conectar..." );
		Conexao cnx = new Conexao();

		System.out.println( "Conectado" );
		
		//exemploComandoInsertSimples( cnx );
		//exemploComandoInsertComParametros ( cnx, 8, "Antonio Carlos Da Silva", "12332143211", 291292.22 );
	
		exemploSelect( cnx );
		
		
	}

	private static void exemploSelect(Conexao cnx) throws SQLException, IOException {

		Statement s = cnx.getConexao().createStatement();
		ResultSet rs = s.executeQuery( "select * from usuarios" );
		
		/* Primeiro eu mando posicionar na primeira linha.  Se retornar true, é porque
		 * o select retornou dados */
		if( rs.next() ) {
			
			System.out.println("\nID - Nome - E-mail - Perfil");
			
			while( !rs.isAfterLast() ) {
				
				System.out.println( String.format("%d - %s - %s - %d", 
						rs.getInt( "id_user"),
						rs.getInt("nome"),
						rs.getString( "email"),
						rs.getString( "perfil")
					));
				
				rs.next();
			}
		} else {
			System.out.println( "O comando não retornou dados" );
		}
	}

	private static void exemploComandoInsertComParametros( Conexao cnx, int id_User, String nome, String email, String senha, int perfil, int PrimeiroAcesso ) throws SQLException, IOException {
		
		String comando = "insert into usuarios (id_user, nome, email, senha, perfil, PrimeiroAcesso) values ( ?, ?, ?, ?, ?, ?)";
		
		PreparedStatement ps = cnx.getConexao().prepareStatement( comando );
		
		ps.setInt(1, id_User);
		ps.setString(2, nome);
		ps.setString(3, email);
		ps.setString(4, senha);
		ps.setInt(5, perfil);
		ps.setInt(6, PrimeiroAcesso);
		
		ps.execute();
	}
}
