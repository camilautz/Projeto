package feevale.projeto.ConexaoBD;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author Camila Utz
 */
public class ParametrosBD {
    
    /* Cria-se um atributo estático que permitirá a manipulação e controle
	 * da instância criada */
	private static ParametrosBD mySelf;
	
	private Properties parametros; 
	
	/* Primeiro passo para a criação de um Sigletom é a declaração de um construtor 
	 * privado, como abaixo.  Este providencia impede que esta classe seja instanciada
	 * for dela mesmo.
	 */
	private ParametrosBD() throws IOException {
		
		FileInputStream fis = new FileInputStream( "C:/Users/camil/Desktop/RMI/projeto/ParametrosDB.xml" );
		
		try {
		
			parametros = new Properties();
			parametros.loadFromXML( fis );
		} finally {
			fis.close();
		}
	}
	
	/* Finalmente adiciona-se à classe um método estático, que retornará a instância
	 * criada da classe Singletom */
	public static ParametrosBD getInstance() throws IOException {
		
		if( mySelf == null ) {
			mySelf = new ParametrosBD();
		}
		
		return mySelf;
	}
	
	public String getParameter( String name ) {
		return parametros.getProperty( name );
	}
	
	public void inicParametros() throws IOException {
		
		Properties p = new Properties();
		p.setProperty( "driverJDBC", "org.postgresql.Driver" );
		p.setProperty( "urlAcesso", "jdbc:postgresql://localhost:5432/Banco_SD" );
		p.setProperty( "usuario", "postgres");
		p.setProperty( "senha", "admin");
		
		FileOutputStream fos = new FileOutputStream( "ParametrosDB.xml" );
		
		try {
			p.storeToXML( fos, "Arquivo de Parâmetros - Feevale" );
		} finally {
			fos.close();
		}
		
	}
    
}
