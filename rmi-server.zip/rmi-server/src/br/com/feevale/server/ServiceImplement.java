/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.feevale.server;

import br.com.feevale.core.Service;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

/**
 *
 * @author pbarros
 */
public class ServiceImplement implements Service{
    
    private Vector posts;

    @Override
    public String getDataHora() throws RemoteException {
        SimpleDateFormat _dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        return _dateTimeFormat.format(Calendar.getInstance().getTime());
    }
    
    @Override
    public String invertString(String _valor) throws RemoteException {
        String _strInvertida = "";
        StringBuffer _buffer = new StringBuffer(_valor);
        _strInvertida = _buffer.reverse().toString();
        return _strInvertida;
    }    
    
    // O construtor padrao deve gera a excessao RemoteException
    public ServiceImplement() throws RemoteException {
        posts = new Vector();
    }
    //Postar mensagens
    public void postMessage(String author, String aMessage) throws RemoteException {
        posts.add(author + " disse uma vez: " + aMessage);
    }
    //Leitor de mensagens todas as mensagens
    public String[] readPosts() throws RemoteException {
        String[] result = new String[posts.size()];
        posts.toArray(result);
        return result;
    }
    
    //Ler mensagens a partir de um ponto
    public String[] readPosts(int beginAt) throws RemoteException {
        String[] results = readPosts();
        String[] copy = new String[results.length - beginAt];
        System.arraycopy(results, beginAt, copy, 0, copy.length);
        return copy;
    }
    
    @Override
    public String naoCadastrado() throws RemoteException{ 
        return "Nao cadastrado";
    }
    
    public void realizarBackup() throws RemoteException{
    	//procedimento de backup
    }
    
    public String restaurarBackup() throws RemoteException{
    	return "Backup restaurado com sucesso!";
    }
    
    public String listarTopicos() throws RemoteException{
    	return "Lista de topicos";
    }
    
    public void inscreverEmTopico(int indice) throws RemoteException{
    	//realiza inscri��o em topico por indice
    	int indiceTopico = indice;
    }
    
    public String consultarNoticiaDeTopicoPorData(int topico, String dataInicial, String dataFinal) throws RemoteException{
    	//realiza consulta de noticias em topico por intervalo de data
    	String noticias = "consulta de noticias de topico por data";
    	return noticias;
    }
    
    public String consultarUltimaNoticiaDeTopico(int topico) throws RemoteException{
    	//realiza consulta da ultima noticias em topico
    	String noticias = "consulta da ultima noticia em topico";
    	return noticias;
    }
    
    public void adicionarTopico(String nome) throws RemoteException{
    	//cria mais 1 topico
    	
    }
    
    public void inserirNoticiaEmTopico(int topico, String noticia) throws RemoteException{
    	//inseri noticia em topico
    	
    }
    
    public String consultarTodasAsNoticias() throws RemoteException{
    	//realiza consulta de todas as noticias
    	String noticias = "consulta todas as noticias";
    	return noticias;
    }
}
