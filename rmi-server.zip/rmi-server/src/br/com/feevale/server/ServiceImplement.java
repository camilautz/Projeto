/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.feevale.server;

import br.com.feevale.core.Service;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

/**
 *
 * @author pbarros
 */
public class ServiceImplement implements Service{

    @Override
    public String getDataHora() throws RemoteException {
        SimpleDateFormat _dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        return _dateTimeFormat.format(Calendar.getInstance().getTime());
    }

    @Override
    public String invertString(String _valor) throws RemoteException {
        String _strInvertida = "";
        StringBuffer _buffer = new StringBuffer(_valor);
        _strInvertida = _buffer.reverse().toString();
        return _strInvertida;
    }
    
    private Vector posts;
    
    // O construtor padr�o deve gera a exe��o RemoteException
    public ServiceImplement() throws RemoteException {
        posts = new Vector();
    }

    public void postMessage(String author, String aMessage) throws RemoteException {
        posts.add(author + " disse uma vez: " + aMessage);
    }

    public String[] readPosts() throws RemoteException {
        String[] result = new String[posts.size()];
        posts.toArray(result);
        return result;
    }

    public String[] readPosts(int beginAt) throws RemoteException {
        String[] results = readPosts();
        String[] copy = new String[results.length - beginAt];
        System.arraycopy(results, beginAt, copy, 0, copy.length);
        return copy;
    }
}
