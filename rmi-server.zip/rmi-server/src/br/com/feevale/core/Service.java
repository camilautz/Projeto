package br.com.feevale.core;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author pbarros
 */
public interface Service extends Remote{
    public String getDataHora() throws RemoteException;    
    public String invertString(String _valor) throws RemoteException;
    public void postMessage(String author, String aMessage) throws RemoteException;
    public String[] readPosts() throws RemoteException;
    public String[] readPosts(int beginAt) throws RemoteException;
    public String naoCadastrado() throws RemoteException;
    public void realizarBackup() throws RemoteException;
    public String restaurarBackup() throws RemoteException;
    public String listarTopicos() throws RemoteException;
    public void inscreverEmTopico(int indice) throws RemoteException;
    public String consultarNoticiaDeTopicoPorData(int topico, String dataInicial, String dataFinal) throws RemoteException;
    public String consultarUltimaNoticiaDeTopico(int topico) throws RemoteException;
    public void adicionarTopico(String nome) throws RemoteException;
    public void inserirNoticiaEmTopico(int topico, String noticia) throws RemoteException;
    public String consultarTodasAsNoticias() throws RemoteException;
    

}
