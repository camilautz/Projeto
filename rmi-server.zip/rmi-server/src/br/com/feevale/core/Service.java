package br.com.feevale.core;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author pbarros
 */
public interface Service extends Remote{
    public String getDataHora() throws RemoteException;
    public String invertString(String _valor) throws RemoteException;
    public void postMessage(String author, String aMessage) throws RemoteException;
    public String[] readPosts() throws RemoteException;
    public String[] readPosts(int beginAt) throws RemoteException;

}
